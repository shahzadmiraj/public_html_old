jQuery(document).ready(function($) {
	$('#_wc_deposit_payment_plans').select2();
});