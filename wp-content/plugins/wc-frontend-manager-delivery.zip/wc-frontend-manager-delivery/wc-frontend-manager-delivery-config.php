<?php

define('WCFMd_TOKEN', 'wcfmd');

define('WCFMd_TEXT_DOMAIN', 'wc-frontend-manager-delivery');

define('WCFMd_VERSION', '1.2.8');

define('WCFMd_SERVER_URL', 'https://wclovers.com');

?>