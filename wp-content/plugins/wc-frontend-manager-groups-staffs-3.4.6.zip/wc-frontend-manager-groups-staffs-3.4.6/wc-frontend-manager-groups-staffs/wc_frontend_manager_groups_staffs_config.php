<?php

define('WCFMgs_TOKEN', 'wcfmgs');

define('WCFMgs_TEXT_DOMAIN', 'wc-frontend-manager-groups-staffs');

define('WCFMgs_VERSION', '3.4.6');

define('WCFMgs_SERVER_URL', 'https://wclovers.com');

?>